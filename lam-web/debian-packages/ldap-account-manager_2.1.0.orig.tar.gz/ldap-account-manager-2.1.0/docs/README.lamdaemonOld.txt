
ATTENTION! This version of lamdaemon is no longer supported, please use the new lamdaemon instead!


   Setting up lamdaemon:


 LamdaemonOld.pl is used to modify quota and home directories on a remote or local host via ssh.
 If you want wo use it you have to set up some things to get it to work:


1. Setup values in LDAP Account Manager
   * Set the remote or local host in the configuration
    (e.g. 127.0.0.1)
   * Path to lamdaemonOld.pl, e.g. /srv/www/htdocs/lam/lib/lamdaemonOld.pl
     If you installed a Debian or RPM package then the script may be located at
     /usr/share/ldap-account-manager/lib or /var/www/html/lam/lib.


2. Set up sudo
   The perl script has to run as root. Therefore we need
   a wrapper, sudo.
   Edit /etc/sudoers on host where homedirs or quotas should be used
   and add the following line:
   
   $admin All= NOPASSWD: $path
   
   $admin is the adminuser from LAM and $path is the path to lamdaemonOld.pl
   e.g. "$admin All= NOPASSWD: /srv/www/htdocs/lam/lib/lamdaemonOld.pl"
   At the moment the password is a paramteter of lamdaemonOld.pl
   therefore you should disable logging so the password does not
   appear in any logfile.
   This can be done by adding the following line to /etc/sudoers:

   Defaults:$admin !syslog


3. Set up Perl
   We need some external Perl modules, Quota and Net::SSH::Perl
   To install them, run:

   perl -MCPAN -e shell
   install Quota                 # required
   install Net::SSH::Perl        # required
   install Math::BigInt::GMP     # optional but very poor performance if not installed

   If your Perl executable is not located in /usr/bin/perl you will have to edit
   the path in the first line of lamdaemonOld.pl.
   If you have problems compiling the Perl modules try installing a newer release
   of your GCC compiler and the "make" application.

   Debian users can install Net::SSH:Perl with dh-make-perl:

   apt-get install dh-make-perl
   dh-make-perl --build --cpan Net::SSH::Perl
   dpkg -i libnet-ssh-perl_1.25-1_all.deb


4. Set up SSH
   Your SSH daemon must offer the password authentication method.
   To activate it just use this configuration option in /etc/ssh/sshd_config:

   PasswordAuthentication yes


5. Test lamdaemonOld.pl
   There is a test-function in lamdaemonOld.pl. Please run lamdaemonOld.pl
   with the following parameters to test it:

   lamdaemonOld.pl $ssh-server $lam_path_on_host $admin-username $admin-password *test

   $ssh-server is the remote host lamdaemonOld.pl should be run on
   $lam_path_on_host is the path to lamdaemonOld.pl on remote host
   $admin-username is the name of the user which is allowed to run lamdaemonOld.pl
                   as root. It is the same user as in /etc/sudoers
   $admin-password is the password of the admin user
   *test is the command which tells lamdaemonOld.pl to test settings

   You have to run the command as the user your webserver is running, e.g.

   wwwrun@tilo:/srv/www/htdocs/lam/lib> /srv/www/htdocs/lam/lib/lamdaemonOld.pl \
     127.0.0.1 /srv/www/htdocs/lam/lib/lamdaemonOld.pl adminuser secret *test

   You should get the following response:

     Net::SSH::Perl successfully installed.
     Perl quota module successfully installed.
     If you have not seen any error lamdaemonOld.pl should be set up successfully.
 
 
   !!! Attention !!!
   Your password in LDAP has to be hashed with CRYPT. If you use something like SSHA
   you will probably get "Access denied.".

   Now everything should work fine.


6. Debugging lamdaemon
   If you set up all things as documented before and still get "Access denied"
   then you can try to debug the problem.

   - Check /var/log/auth.log or the equivalent on your system
     This file contains messages about all logins. If the ssh login
     failed then you will find a description about the reason here.

   - Enable debug output in lamdaemon
     In line 235 of lamdaemonOld.pl change the SSH options like this:

     my $ssh = Net::SSH::Perl->new($hostname, options=>[
       "UserKnownHostsFile /dev/null"],
       protocol => "2,1", debug => 1 );

     This will produce a lot of output when you do the lamdaemon test.
     Check that there is a line like this:
  
     Authentication methods that can continue: publickey,password,keyboard-interactive.

     The "password" is the one which is important.

   - Set sshd in debug mode
     In /etc/ssh/sshd_conf add these lines:

     SyslogFacility AUTH
     LogLevel DEBUG3

     Now check /var/log/syslog for messages from sshd.

   - Update Openssh
     A Suse Linux user reported that upgrading Openssh solved the problem.


Security warning:
-----------------

   If you use PHP < 4.3 your admin user and password are passed as commandline argument.
   This can be a security risk. Upgrade your PHP version for productive use.


Please send a mail to TiloLutz@gmx.de if you have any suggestions.
